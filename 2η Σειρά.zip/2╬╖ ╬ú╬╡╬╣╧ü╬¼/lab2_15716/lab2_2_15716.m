clear all; close all;
load sima;
% ���������� Parks-MacClellan
H=[zeros(1,750) ones(1,950-750) zeros(1,Fs/2 -950)];
figure;
stem(H);
hpm=firpm(128, [0 0.10 0.15 0.5]*2, [1 1 0 0]);
% figure; freqz(hpm,1);
%kaiser
h=ifft(H,'symmetric');
middle=length(h)/2;
h32=h(middle+1-16:middle+17);
h64=h(middle+1-32:middle+33);
h128=h(middle+1-64:middle+65);
h256=h(middle+1-128:middle+129);
wvtool(h256);
wk=kaiser(length(h256),5);
figure; plot(0:256,wk,'r'); grid;
h_kaiser=h256.*wk';
wvtool(h_kaiser);
y_kais=conv(s,h_kaiser);
figure; pwelch(y_kais,[],[],[],Fs);