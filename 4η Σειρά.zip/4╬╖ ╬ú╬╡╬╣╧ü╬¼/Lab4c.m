function errors=Lab4c(k,Nsymb,nsamp,EbNo)
x = randi([0, 1], 1,10000);
L=2^k;
delay=4;
rolloff=0.25;
step=2; 
mapping=-(L-1):step:(L-1);

SNR=EbNo-10*log10(nsamp/2/k);
f=reshape(x,k,Nsymb).';
xsym=bi2de(f,'left-msb')
y=[];
for i=1:length(xsym)
    y=[y mapping(xsym(i)+1)];
end
yt=upsample(y,nsamp);
filterorder = delay*nsamp*2;
rNyquist = rcosine(1,nsamp,'fir/sqrt',rolloff,delay);
k=log2(L);
ytx = conv(yt,rNyquist);
ynoisy = awgn(ytx, SNR, 'measured');
yrx=conv(ynoisy,rNyquist);
yrx = downsample(yrx,nsamp); 
yrx=yrx(2*delay*nsamp+1:end-2*delay*nsamp); 
xr = [];
for i=1:length(yrx)
    [m,j]=min(abs(mapping-yrx(i)));
    xr = [xr de2bi(j-1, k, 'left-msb')];
end
errors = sum(not(x == xr));
end