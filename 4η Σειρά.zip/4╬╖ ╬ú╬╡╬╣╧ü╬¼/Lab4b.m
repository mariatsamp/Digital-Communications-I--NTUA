function errors=Lab4b(k,Nsymb,nsamp,EbNo)
L=2^k;
step=2; 
k=log2(L);
delay=4;
filtorder=128; %=delay*nsamp*2
rolloff=0.1;
x = randi([0, 1], 1,10000);
SNR=EbNo-10*log10(nsamp/2/k);
rNyquist = rcosine(1,nsamp,'fir/sqrt',rolloff,delay);
mapping=[step/2; -step/2];
if(k>1)
 for j=2:k
 mapping=[mapping+2^(j-1)*step/2; ...
 -mapping-2^(j-1)*step/2];
 end
end;
xsym=bi2de(reshape(x,k,length(x)/k).','left-msb');
y=[];
for i=1:length(xsym)
 y=[y mapping(xsym(i)+1)];
end
%%%%
yt=upsample(y,nsamp);
ytx = conv(yt,rNyquist);
ynoisy = awgn(ytx, SNR, 'measured');
yrx=conv(ynoisy,rNyquist);
yrx=yrx(2*delay*nsamp+1:end-2*delay*nsamp); 
yrx = downsample(yrx,nsamp); 
plot(yrx(1:10*nsamp)); hold; 
stem((1:nsamp:10*nsamp), y(1:10),'filled');
grid;
%figure();
%pwelch(ytx);
xr = [];
for i=1:length(yrx)
    [m,j]=min(abs(mapping-yrx(i)));
    xr = [xr de2bi(j-1, k, 'left-msb')];
end
errors = sum(not(x == xr));
end