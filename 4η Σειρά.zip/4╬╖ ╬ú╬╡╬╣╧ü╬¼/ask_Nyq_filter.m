function errors=ask_Nyq_filter(k,Nsymb,nsamp,EbNo)
k=5; Nsymb=10000; nsamp=16;
L=2^k;
L=32;
x = randi([0, 1], 1,10000);
delay=4;
filtorder=128; %=delay*nsamp*2
rolloff=0.25;
rNyquist = rcosine(1,nsamp,'fir/sqrt',rolloff,delay);
step=2; % � ������� ��� ������ ��� �� ���� ������ ����
k=log2(L);
mapping=[step/2; -step/2];
if(k>1)
 for j=2:k
 mapping=[mapping+2^(j-1)*step/2; ...
 -mapping-2^(j-1)*step/2];
 end
end;
xsym=bi2de(reshape(x,k,length(x)/k).','left-msb');
y=[];
for i=1:length(xsym)
 y=[y mapping(xsym(i)+1)];
end
yt=upsample(y,nsamp);
ytx = conv(yt,rNyquist);
yrx=conv(ytx,rNyquist);
yrx=yrx(2*delay*nsamp+1:end-2*delay*nsamp); 
plot(yrx(1:10*nsamp)); hold; 
stem((1:nsamp:10*nsamp), y(1:10),'filled');
grid; 
 l=[-L+1:2:L-1];
 for i=1:length(yrx)
 [m,j]=min(abs(l-yrx(i)));
 end;



