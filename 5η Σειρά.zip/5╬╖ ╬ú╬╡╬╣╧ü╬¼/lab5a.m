close all; clear all;
L=4;
M = L^2;
l=log2(L);
k = 2*l;
core=[1+i;1-i;-1+i;-1-i]; % ���������� ������������, M=4
mapping=core;
if(l>1)
 for j=1:l-1
 mapping=mapping+j*2*core(1);
 mapping=[mapping;conj(mapping)];
 mapping=[mapping;-conj(mapping)];
 end
end;
scatterplot(mapping);
axis([-L L -L L]);
for j=1:length(mapping)
    display(real(mapping(j)));
    display(imag(mapping(j)));
    text(real(mapping(j)),imag(mapping(j))+0.5,num2str(de2bi(j-1,k,'left-msb')), 'FontSize', 6); 
end
    