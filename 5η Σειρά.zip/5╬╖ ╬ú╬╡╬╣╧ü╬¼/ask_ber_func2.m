function [ber,numBits] = ask_ber_func(EbNo, maxNumErrs, maxNumBits)
    % Import Java class for BERTool.
    import com.mathworks.toolbox.comm.BERTool;
    % Initialize variables related to exit criteria.
    totErr = 0; % Number of errors observed
    numBits = 0; % Number of bits processed
    k= 6;
    % number of bits per symbol
    Nsymb=2000; % number of symbols in each run
    nsamp=16;
    while((totErr < maxNumErrs) && (numBits < maxNumBits))
    % Check if the user clicked the Stop button of BERTool.
    if (BERTool.getSimulationStop)
    break;
    end
    errors=ask_errors(k,Nsymb,nsamp,EbNo);
    totErr=totErr+errors;
    numBits=numBits + k*Nsymb;
    end
    ber = totErr/numBits;