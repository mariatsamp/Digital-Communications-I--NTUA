function errors = ask_errors(k,Nsymb,nsamp,EbNo)
M = 2^k;
L = sqrt(M);
l = log2(L);

R = 12 * 10^(6);
fmax = 9.25*10^(6);
fmin = 6.75*10^(6);
W = fmax - fmin;
 
fc = (fmax + fmin)/2;
T = log2(M)/R;
fs = nsamp/T;
SNR=EbNo-10*log10(nsamp/k/2);

core=[1+i;1-i;-1+i;-1-i];
mapping=core;
if(l>1)
  for j=1:l-1
    mapping=mapping+j*2*core(1);
    mapping=[mapping;conj(mapping)];
    mapping=[mapping;-conj(mapping)];
  end
end

%Gray Coding
x = floor(2*rand(k*Nsymb,1));
xsym = bi2de(reshape(x,k,length(x)/k).','left-msb')';
y = [];
for n = 1:length(xsym)
  y = [y mapping(xsym(n)+1)];
end

%Pulses
rolloff =0.125;
delay = 8;
filtorder = delay*nsamp*2;

%Filter response Nyquist
rNyquist= rcosine(1,nsamp,'fir/sqrt',rolloff,delay);

%% Transmission
ytx = upsample(y,nsamp);          %Upsampling
ytx = conv(ytx,rNyquist);
%In phase
figure(1); 
pwelch(real(ytx),[],[],[],fs);
% Quadrature modulation
m = (1:length(ytx));
s = real(ytx.*exp(1j*2*pi*fc*m/fs));
figure(2); 
pwelch(s,[],[],[],fs);

Ps=10*log10(s*s'/length(s));
Pn=Ps-SNR
% αντίστοιχη ισχ�?ς θο�?�?βου, σε db
n=sqrt(10^(Pn/10))*randn(1,length(ytx));
snoisy=s+n; % θο�?υβ�?δες ζωνοπε�?ατ�? σήμα

% Demodulation
yrx = 2*snoisy.*exp(-1j*2*pi*fc*m/fs); 
yrx = conv(yrx,rNyquist);

figure(3); 
pwelch(real(yrx),[],[],[],fs);

yrx_downsampled = downsample(yrx,nsamp); 
yrx_with_out_delay = yrx_downsampled(2*delay+(1:length(y)));

%In phase & Quadrature 
yi=real(yrx_with_out_delay); 
yq=imag(yrx_with_out_delay); 

%Decision
xrx=[];
q=[-L+1:2:L-1];
for n=1:length(yrx_with_out_delay) 
  [m,j]=min(abs(q-yi(n)));
  yi(n)=q(j);
  [m,j]=min(abs(q-yq(n)));
  yq(n)=q(j);
  m=1;
  while (mapping(m)~=yi(n)+i*yq(n)) 
    m=m+1; 
  end
  xrx=[xrx; de2bi(m-1,k,'left-msb')'];
end
scatterplot(yrx_with_out_delay)
errors = sum(not(xrx==x))
end