%my_function_ask_errors3
clc;
clear all;
close all;
k=3;
L=2^k;
M=50000;
nsamp=16;
EbNo=(0:2:20);
BER=zeros(1,length(EbNo));
for i=1:length(EbNo)
    Pe=ask_errors(k,M,nsamp,EbNo(i))/M;
    BER(i)=Pe/k;
end
Pe=((L-1)./L)*erfc((EbNo*3*k./(L^2-1))).^(1/2) ;
BER_theory=Pe/k;
semilogy(EbNo,BER,'x',EbNo,BER_theory);
grid on;
title 'BER of 8-Ask with NRZ pulses';

