function [ber,numBits] = ask_ber_func(EbNo, maxNumErrs, maxNumBits)
import com.mathworks.toolbox.comm.BERTool;
totErr=0;
numBits=0;
%k=3;
%Nsymb=50000;
%nsamp=8;
k=4;
Nsymb=10000;
nsamp=16;
while((totErr < maxNumErrs) && (numBits < maxNumBits))
    if (BERTool.getSimulationStop)
        break;
    end
    errors=Lab4c2(k,Nsymb,nsamp,EbNo);
    totErr=totErr+errors;
    numBits=numBits + Nsymb;
end
ber=totErr/numBits;